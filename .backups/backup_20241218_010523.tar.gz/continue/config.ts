export function modifyConfig(config: Config): Config {
  return config;
}